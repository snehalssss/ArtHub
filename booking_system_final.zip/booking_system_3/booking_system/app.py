from flask import Flask, render_template, jsonify, request,redirect, url_for,session,make_response
import mysql.connector
import json
import string
import random
import datetime
import pdfkit
from flask_sqlalchemy import SQLAlchemy
import mysql.connector

app = Flask(__name__)

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="ghibli",
    database="art_shows"
)
cursor = connection.cursor()

# Check if the database tables exist, if not, create them
def create_tables():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS shows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    start_time TIME NOT NULL,
    location VARCHAR(500) NOT NULL,
    event_date DATE NOT NULL,
    available_seats INT NOT NULL
)
    """)
    
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    show_id INT NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    seat_count INT NOT NULL,
    FOREIGN KEY (show_id) REFERENCES shows(id)
)

    """)

app.secret_key = 'your_secret_key_here'

@app.route('/add_event', methods=['GET','POST'])
def add_event():
    
    if request.method == 'POST':
        title = request.form['title']
        start_time = request.form['start_time']
        location = request.form['location']
        event_date = request.form['event_date']
        available_seats = request.form['available_seats']
        #description  = request.form['description']

        # Generate a random event key
        #event_key = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

        # Add the new event to the database
        cursor.execute("INSERT INTO shows (title, start_time, location, event_date, available_seats) VALUES (%s, %s, %s, %s,%s)", (title, start_time, location, event_date, available_seats))
        connection.commit()
        event_confirmed = True
        
        # Return the event key in the response
       # return json.dumps({"This is your event key": event_key}), 200  # Return the event key in JSON format
        return render_template('add_event.html', event_confirmed=event_confirmed)

    return render_template('add_event.html', event_confirmed=False)
    #return render_template('add_event.html',, event_confirmed=event_confirmed)

@app.route('/event_confirmed')
def event_confirmed():
    return "Event added successfully! Thank you for your interest."

@app.route('/show_details', methods=['GET', 'POST'])
@app.route('/show_details/<int:show_id>', methods=['GET', 'POST'])
def show_details(show_id=None):
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        seat_count = request.form['seat_count']

        # Assuming you have a table named 'bookings' with appropriate columns
        cursor.execute("INSERT INTO bookings (show_id, customer_name, seat_count) VALUES (%s, %s, %s)", (show_id, customer_name, seat_count))
        connection.commit()

        return render_template('show_details.html')  # Render booking confirmation page after successful booking

    else:
        if show_id is not None:
            # Fetching show details using join operation
            cursor.execute("SELECT art_shows.shows.*, bookings.customer_name, bookings.seat_count FROM art_shows.shows INNER JOIN bookings ON art_shows.shows.id = bookings.show_id WHERE art_shows.shows.id = %s", (show_id,))
            show_details = cursor.fetchone()

            if show_details:
                return render_template('show_details.html', show_details=show_details)
            else:
                return "Show not found"
        else:
            return "No show ID provided"

# @app.route('/generate_pdf', methods=['POST'])
# def generate_pdf():
#     # Retrieve data from the request JSON
#     data = request.json
#     show_title = data.get('show_title')
#     location = data.get('location')
#     event_date = data.get('event_date')
#     start_time = data.get('start_time')

#     # Render HTML template with data
#     html = render_template('generate_pdf.html', show_title=show_title, location=location, event_date=event_date, start_time=start_time)

#     # Generate PDF from HTML
#     pdf = pdfkit.from_string(html, False)

#     # Create response with PDF as attachment
#     response = make_response(pdf)
#     response.headers['Content-Type'] = 'application/pdf'
#     response.headers['Content-Disposition'] = 'attachment; filename=booking_confirmation.pdf'

#     return response
@app.route('/generate_pdf', methods=['GET'])
def generate_pdf():
    try:
        # Write queries to fetch data from the database
        query = """
            SELECT b.show_id, b.customer_name, s.id, s.title, s.start_time, s.location, s.event_date
            FROM art_shows.bookings AS b
            JOIN art_shows.shows AS s ON b.show_id = s.id
            ORDER BY b.id DESC
            LIMIT 1
        """
        
        # Execute the query
        cursor = connection.cursor()
        cursor.execute(query)
        
        # Fetch the result of the query
        data = cursor.fetchone()

        # Close the cursor
        cursor.close()

        # Pass the data to the frontend and render the template
        return render_template('generate_pdf.html', show_id=data[0], customer_name=data[1], id=data[2], title=data[3], start_time=data[4], location=data[5], event_date=data[6])
    except Exception as e:
        # Handle exceptions, such as database errors
        return str(e)

# def get_show_details(show_id):
#     for show in art_shows:
#         if show['id'] == show_id:
#             return show
        
@app.route('/book/<int:show_id>', methods=['GET', 'POST'])
def book_show(show_id):
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        seat_count = int(request.form['seat_count'])
        
        # Insert booking details into the database
        cursor.execute("INSERT INTO bookings (show_id, customer_name, seat_count) VALUES (%s, %s, %s)", (show_id, customer_name, seat_count))
        connection.commit()
        
        # Update available seats in the shows table
        cursor.execute("UPDATE shows SET available_seats = available_seats - %s WHERE id = %s", (seat_count, show_id))
        connection.commit()
        
        # Fetch show details for the given show_id
        cursor.execute("SELECT title, start_time, location, event_date FROM shows WHERE id = %s", (show_id,))
        show_details = cursor.fetchone()
        
        if show_details:
            show_title, start_time, location, event_date = show_details
        else:
            # Handle case where show_id doesn't exist
            return "Show not found"
        
        # Render the booking confirmation message on the same page
        return render_template('booking_page.html', show_id=show_id, show_title=show_title, start_time=start_time, location=location, event_date=event_date, booking_success=True)
    
    # Fetch show details for the given show_id
    cursor.execute("SELECT title, start_time, location, event_date, available_seats FROM shows WHERE id = %s", (show_id,))
    show_details = cursor.fetchone()
    
    if show_details:
        show_title, start_time, location, event_date, available_seats = show_details
    else:
        # Handle case where show_id doesn't exist
        return "Show not found"
    
    return render_template('booking_page.html', show_id=show_id, show_title=show_title, start_time=start_time, location=location, event_date=event_date, available_seats=available_seats)


@app.route('/booking_success')
def booking_success():
    return "Booking successful! Thank you for booking."

@app.route('/')
def index():
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM shows")  # Assuming 'shows' is your table name
    shows = cursor.fetchall()
    return render_template('index.html', shows=shows)

# @app.route('/get_shows')
# def get_shows():
#     try:
#         cursor.execute("SELECT * FROM shows")
#         shows = cursor.fetchall()
#         return jsonify({'shows': shows})
#     except Exception as e:
#         return jsonify({'error': str(e)})

# @app.route('/show_details/<int:show_id>')
# def show_details(show_id):
#     show_details = get_show_details(show_id)
#     return render_template('show_details.html', show_details=show_details)

if __name__ == '__main__':
    app.run(debug=True)


